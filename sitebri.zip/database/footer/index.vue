<template src="./footer.html"></template>
<script src="./footer.js"></script>
<style src="./footer.scss" scoped lang="scss"></style>

