<?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $forum = app('App\Utility\SimplifyForum'); ?>
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Laravel</title>

    </head>
    <body>
      <main class="main-content">
        <div class="content-wrapper">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-3  topics-choose">
                <button type="button" class="btn topics-lg-btn">NOUVEAU SUJET</button>
                <br />
                <br />
                <h3 class="title_topics">Sujets :</h3>
                <ul class="list-group categories">
                  <li>
                      <i class="fas fa-square"></i>
                      <a href="/forum/category/tout" style="color:grey" class="">Tout</a>
                  </li>
                  <li>
                      <i class="fas fa-square" ></i>
                      <a style="color:grey">Top 14</a>
                  </li>
                  <li>
                      <i class="fas fa-square"></i>
                      <a style="color:grey">Actualités</a>
                  </li>
                  <li>
                      <i class="fas fa-square" ></i>
                      <a href="/forum/category/communaute" style="color:grey">Communauté</a>
                  </li>
                  <li>
                      <i class="fas fa-square" style="color:#d72d2d"></i>
                      <a style="color:grey" href="/forum/category/problèmes">Problèmes</a>
                  </li>
                  <li>
                      <i class="fas fa-square"></i>
                      <a style="color:grey">Demande</a>
                  </li>
                  <br />
                </ul>
              </div>
              <div class="col-md-9  topics_list ">
                <div class="section section--posts">
                  <div class="form-group " >
                      <select class="btn btn-dropdown" id="topics-selecter">
                        <option>Tout</option>
                        <option>Top 14</option>
                        <option>Actualités</option>
                        <option>Communauté</option>
                        <option>Problèmes</option>
                        <option>Demande</option>
                      </select>
                      <select class="btn btn-dropdown">
                        <option>Trier par:Récent</option>
                        <option>Trier par:Polulaire</option>
                      </select>
                  </div>
                  <ul>
                    <?php if(!empty($topics)): ?>
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="topics_il">
                          <div class="avatar-topics">

                          </div>
                          <div class="upper-topics"><a  class="title-topics" href="/forum/category/<?php echo e($topic->category); ?>/<?php echo e($topic->id); ?>"><?php echo e($topic->title); ?></a></div>
                          <div class="upper-topics">
                            <i class="fas fa-share comment-topics fa-rotate-180" style="color:black;"></i>
                            <span  class="comment-topics ml-1" style="color:black;"><?php echo e($topic->editor); ?></span>
                            <span class="comment-ago">commentée <?php echo e($topic->date); ?></span>
                            <i class="far fa-comments comment-topics" style="font-size:16px;"></i>
                            <span class="comment-topics ml-1"><?php echo e($topic->vues); ?></span>
                            <?php if(empty($topic->warning)||$topic->warning == false): ?>
                              <button type="button" class="btn-topics btn btn-outline-primary btn-sm"><?php echo e($topic->category); ?></button>
                            <?php endif; ?>
                            <?php if(!empty($topic->warning)&&$topic->warning == true): ?>
                              <button type="button" class="btn-topics btn btn-outline-danger btn-sm"><?php echo e($topic->category); ?></button>
                            <?php endif; ?>
                          </div>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </ul>
                  <?php if(!empty($topics)): ?>
                    <div class="nav-scroller py-1 mb-2">
                      <nav class="nav d-flex justify-content-center">
                        <?php echo $topics->links(); ?>

                      </nav>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    <script src="/js/forum.js"></script>
    </body>
</html>
