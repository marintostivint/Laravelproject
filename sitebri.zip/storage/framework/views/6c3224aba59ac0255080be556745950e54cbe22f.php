<?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $forum = app('App\Utility\SimplifyForum'); ?>
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Laravel</title>

    </head>
    <body>
      <main class="main-content">
        <div class="content-wrapper">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-3  topics-choose">
                <button type="button" class="btn topics-lg-btn">NOUVEAU SUJET</button>
                <br />
                <br />
                <h3 class="title_topics">Sujets :</h3>
                <ul class="list-group categories">
                  <li>
                      <i class="fas fa-square"></i>
                      <a href="/forum/category/tout" style="color:grey" class="">Tout</a>
                  </li>
                  <li>
                      <i class="fas fa-square" ></i>
                      <a style="color:grey">Top 14</a>
                  </li>
                  <li>
                      <i class="fas fa-square"></i>
                      <a style="color:grey">Actualités</a>
                  </li>
                  <li>
                      <i class="fas fa-square" ></i>
                      <a style="color:grey">Communauté</a>
                  </li>
                  <li>
                      <i class="fas fa-square" style="color:#d72d2d"></i>
                      <a style="color:grey" href="/forum/category/problèmes">Problèmes</a>
                  </li>
                  <li>
                      <i class="fas fa-square"></i>
                      <a style="color:grey">Demande</a>
                  </li>
                  <br />
                </ul>
              </div>
                <div class="col-md-9  ">
                    <?php if(!empty($topic)): ?>
                    <h1 class="comment-title"><?php echo e($topic->title); ?></h1>
                    <p class="comment-subtitle">
                      <?php echo $topic->content; ?>

                    </p>
                    <div class="comment-avatar-topics">

                    </div>
                    <span class="comment-avatar-name"><?php echo e($topic->owner); ?> <span class="comment-avatar-name" style="color:grey;font-size:12px;"><?php echo e($topic->date); ?></span></span>
                    <div class="divider"></div>
                    <?php endif; ?>

                    <?php if(!empty($messages)): ?>
                      <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="comment-subtitle">
                              <?php echo $mess->content; ?>

                            </p>
                            <div class="comment-avatar-topics">

                            </div>
                            <span class="comment-avatar-name"><?php echo e($mess->owner); ?> <span class="comment-avatar-name" style="color:grey;font-size:12px;"><?php echo e($mess->date); ?></span></span>
                            <div class="divider"></div>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <div class="nav-scroller py-1 mb-2">
                        <nav class="nav d-flex justify-content-center">
                          <?php echo $messages->render(); ?>

                        </nav>
                      </div>

                    <?php endif; ?>
                <?php if(!empty($topic)): ?>
                <form action="/forum/forum-post" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($topic->id); ?>" />
                  <?php if(auth()->guard()->check()): ?>
                    <button type="submit" class="btn btn-primary btn-sm">Envoyer</button>
                  <?php else: ?>
                    <a href="/connexion"><button type="button" class="btn btn-primary btn-sm">Connecter vous pour envoyer</button></a>
                  <?php endif; ?>
                  <textarea name="content" class="form-control my-editor"></textarea>
                </form>
                <?php endif; ?>
                </div>
              </div>
            </div>
          <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
      </main>
      <script src="/js/forum.js"></script>
    </body>
</html>
