<?php

namespace App\Utility;
use DB;
use Jenssegers\Date\Date;
use Auth;

class SimplifyForum
{
  
}
